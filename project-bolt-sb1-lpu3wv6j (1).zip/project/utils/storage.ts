import AsyncStorage from '@react-native-async-storage/async-storage';
import { HealthLogEntry } from '@/types/health';

const HEALTH_LOG_KEY = 'health_log';

// Generate a unique ID for entries
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// Get all health log entries
export const getHealthLog = async (): Promise<HealthLogEntry[]> => {
  try {
    const jsonValue = await AsyncStorage.getItem(HEALTH_LOG_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : [];
  } catch (e) {
    console.error('Error reading health log:', e);
    return [];
  }
};

// Add a new health log entry
export const addHealthLogEntry = async (entry: Omit<HealthLogEntry, 'id'>): Promise<HealthLogEntry> => {
  try {
    const newEntry: HealthLogEntry = {
      ...entry,
      id: generateId(),
    };
    
    const currentLog = await getHealthLog();
    const updatedLog = [newEntry, ...currentLog];
    
    await AsyncStorage.setItem(HEALTH_LOG_KEY, JSON.stringify(updatedLog));
    return newEntry;
  } catch (e) {
    console.error('Error adding health log entry:', e);
    throw new Error('Failed to save health log entry');
  }
};

// Delete a health log entry
export const deleteHealthLogEntry = async (id: string): Promise<void> => {
  try {
    const currentLog = await getHealthLog();
    const updatedLog = currentLog.filter(entry => entry.id !== id);
    await AsyncStorage.setItem(HEALTH_LOG_KEY, JSON.stringify(updatedLog));
  } catch (e) {
    console.error('Error deleting health log entry:', e);
    throw new Error('Failed to delete health log entry');
  }
};

// Get entries of a specific type
export const getEntriesByType = async (type: string): Promise<HealthLogEntry[]> => {
  try {
    const log = await getHealthLog();
    return log.filter(entry => entry.type === type);
  } catch (e) {
    console.error('Error filtering health log:', e);
    return [];
  }
};

// Get recent entries (last 7 days)
export const getRecentEntries = async (days: number = 7): Promise<HealthLogEntry[]> => {
  try {
    const log = await getHealthLog();
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);
    
    return log.filter(entry => {
      const entryDate = new Date(entry.timestamp);
      return entryDate >= cutoffDate;
    });
  } catch (e) {
    console.error('Error getting recent entries:', e);
    return [];
  }
};

// Clear all health log entries (for testing)
export const clearHealthLog = async (): Promise<void> => {
  try {
    await AsyncStorage.setItem(HEALTH_LOG_KEY, JSON.stringify([]));
  } catch (e) {
    console.error('Error clearing health log:', e);
    throw new Error('Failed to clear health log');
  }
};