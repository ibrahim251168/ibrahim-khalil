import { Platform } from 'react-native';
import { MeasurementType } from '@/types/health';

// Simulate a heart rate measurement
export const simulateHeartRateMeasurement = (): Promise<number> => {
  return new Promise((resolve) => {
    // Simulate measurement delay
    setTimeout(() => {
      // Generate a realistic heart rate (60-100 bpm)
      const heartRate = Math.floor(Math.random() * 41) + 60;
      resolve(heartRate);
    }, 3000);
  });
};

// Simulate heart sound recording
export const simulateHeartSoundRecording = (): Promise<string> => {
  return new Promise((resolve) => {
    // Simulate recording time
    setTimeout(() => {
      resolve('Recording completed successfully');
    }, 4000);
  });
};

// Simulate chest vibration recording
export const simulateChestVibrationRecording = (): Promise<string> => {
  return new Promise((resolve) => {
    // Simulate recording time
    setTimeout(() => {
      resolve('Chest vibration recording completed');
    }, 3000);
  });
};

// Check if a measurement type is available on current platform
export const isMeasurementAvailable = (type: MeasurementType): boolean => {
  // On web, simulate as if all measurements are available
  if (Platform.OS === 'web') {
    return true;
  }
  
  // For native platforms, implement actual checks if needed
  switch (type) {
    case 'heartRate':
      // Would check if camera is available
      return true;
    case 'heartSound':
      // Would check if microphone is available
      return true;
    case 'chestVibration':
      // Would check if accelerometer is available
      return true;
    default:
      return false;
  }
};

// Get measurement instructions based on type
export const getMeasurementInstructions = (type: MeasurementType): string[] => {
  switch (type) {
    case 'heartRate':
      return [
        'Find a well-lit area',
        'Place your fingertip gently over the camera lens',
        'Stay still during the measurement',
        'Keep your finger in place until the measurement completes'
      ];
    case 'heartSound':
      return [
        'Find a quiet environment',
        'Place the phone directly against your chest',
        'Hold still and breathe normally',
        'The recording will take approximately 15 seconds'
      ];
    case 'chestVibration':
      return [
        'Lie down or sit in a comfortable position',
        'Place the phone flat against your chest',
        'Stay still and breathe normally',
        'The recording will take approximately 10 seconds'
      ];
    default:
      return ['Preparing measurement...'];
  }
};