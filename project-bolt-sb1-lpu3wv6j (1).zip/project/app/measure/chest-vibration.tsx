import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { Stack, useRouter } from 'expo-router';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import MeasurementInProgress from '@/components/MeasurementInProgress';
import { Activity } from 'lucide-react-native';
import { simulateChestVibrationRecording } from '@/utils/measurements';
import { addHealthLogEntry } from '@/utils/storage';
import { getMeasurementInstructions } from '@/utils/measurements';

export default function ChestVibrationScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const [isRecording, setIsRecording] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  
  const totalRecordingTime = 3000; // 3 seconds in ms
  const recordingInstructions = getMeasurementInstructions('chestVibration');
  
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isRecording) {
      timer = setInterval(() => {
        setElapsedTime(prev => {
          // Cap at total recording time
          const newTime = Math.min(prev + 100, totalRecordingTime);
          return newTime;
        });
      }, 100);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRecording]);
  
  useEffect(() => {
    if (elapsedTime >= totalRecordingTime && isRecording) {
      completeChestVibrationRecording();
    }
  }, [elapsedTime, isRecording]);
  
  const startRecording = () => {
    setIsRecording(true);
    setElapsedTime(0);
    setResult(null);
    setError(null);
    setSaved(false);
  };
  
  const completeChestVibrationRecording = async () => {
    try {
      const recordingResult = await simulateChestVibrationRecording();
      setResult(recordingResult);
      setIsRecording(false);
    } catch (error) {
      console.error('Error recording chest vibration:', error);
      setError('Failed to record chest vibration. Please try again.');
      setIsRecording(false);
    }
  };
  
  const cancelRecording = () => {
    setIsRecording(false);
    setElapsedTime(0);
  };
  
  const saveToHealthLog = async () => {
    if (result) {
      try {
        await addHealthLogEntry({
          timestamp: new Date().toISOString(),
          type: 'Chest Vibration (SCG)',
          value: 'Recording completed',
          details: 'Chest vibration recording (simulated)'
        });
        setSaved(true);
      } catch (error) {
        console.error('Error saving chest vibration recording:', error);
        setError('Failed to save to health log. Please try again.');
      }
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen 
        options={{ 
          headerShown: true, 
          title: 'Chest Vibration',
          headerTintColor: colors.text,
          headerStyle: {
            backgroundColor: colors.background,
          },
        }} 
      />
      
      <View style={styles.content}>
        {isRecording ? (
          <View style={styles.recordingContainer}>
            <MeasurementInProgress
              type="chestVibration"
              elapsedTime={elapsedTime}
              totalTime={totalRecordingTime}
              instructions={recordingInstructions}
            />
            <Button
              title="Cancel"
              onPress={cancelRecording}
              variant="ghost"
              style={styles.cancelButton}
            />
          </View>
        ) : result ? (
          <View style={styles.resultContainer}>
            <Text style={[styles.resultTitle, { color: colors.text }]}>
              Recording Complete
            </Text>
            
            <Card style={styles.resultCard}>
              <View style={styles.resultHeader}>
                <Activity size={24} color={colors.chestVibration} style={styles.resultIcon} />
                <Text style={[styles.resultHeaderText, { color: colors.text }]}>
                  Chest Vibration (SCG)
                </Text>
              </View>
              
              <Text style={[styles.resultStatus, { color: colors.activity }]}>
                Recording Successful
              </Text>
              
              <Text style={[styles.resultDescription, { color: colors.tabIconDefault }]}>
                This simulated recording would capture the vibrations produced by your heart using
                the device's accelerometer. In a real application, these recordings could be analyzed
                to provide insights about cardiac mechanical function.
              </Text>
              
              <Text style={[styles.technicalNote, { color: colors.tabIconDefault }]}>
                SCG (Seismocardiography) is a non-invasive technique that measures chest wall
                vibrations associated with the heartbeat.
              </Text>
            </Card>
            
            {!saved ? (
              <Button
                title="Save to Health Log"
                onPress={saveToHealthLog}
                style={[styles.saveButton, { backgroundColor: colors.chestVibration }]}
              />
            ) : (
              <Text style={[styles.savedText, { color: colors.activity }]}>
                Saved to Health Log ✓
              </Text>
            )}
            
            <Button
              title="Record Again"
              onPress={startRecording}
              variant="outline"
              style={[styles.recordAgainButton, { borderColor: colors.chestVibration }]}
            />
          </View>
        ) : (
          <View style={styles.startContainer}>
            <Card style={styles.instructionsCard}>
              <Text style={[styles.instructionsTitle, { color: colors.text }]}>
                Chest Vibration Recording
              </Text>
              
              <Text style={[styles.instructionsText, { color: colors.tabIconDefault }]}>
                This feature simulates recording the vibrations produced by your heart using your
                device's accelerometer. These recordings can provide information about your heart's
                mechanical function.
              </Text>
              
              <View style={styles.instructionsList}>
                {recordingInstructions.map((instruction, index) => (
                  <View key={index} style={styles.instructionItem}>
                    <Text style={[styles.instructionNumber, { color: colors.chestVibration }]}>
                      {index + 1}
                    </Text>
                    <Text style={[styles.instructionText, { color: colors.text }]}>
                      {instruction}
                    </Text>
                  </View>
                ))}
              </View>
            </Card>
            
            {error && (
              <Text style={styles.errorText}>{error}</Text>
            )}
            
            <Button
              title="Start Recording"
              onPress={startRecording}
              style={[styles.startButton, { backgroundColor: colors.chestVibration }]}
            />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  recordingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelButton: {
    marginTop: 24,
  },
  resultContainer: {
    flex: 1,
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 20 : 0,
  },
  resultTitle: {
    ...Typography.heading2,
    marginBottom: 24,
  },
  resultCard: {
    width: '100%',
    marginBottom: 24,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultIcon: {
    marginRight: 12,
  },
  resultHeaderText: {
    ...Typography.heading3,
  },
  resultStatus: {
    ...Typography.bodyBold,
    marginBottom: 12,
  },
  resultDescription: {
    ...Typography.body,
    marginBottom: 12,
  },
  technicalNote: {
    ...Typography.caption,
    fontStyle: 'italic',
  },
  saveButton: {
    marginBottom: 12,
    width: '100%',
  },
  savedText: {
    ...Typography.bodyBold,
    marginBottom: 12,
  },
  recordAgainButton: {
    width: '100%',
  },
  startContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  instructionsCard: {
    width: '100%',
    marginBottom: 24,
  },
  instructionsTitle: {
    ...Typography.heading3,
    marginBottom: 16,
  },
  instructionsText: {
    ...Typography.body,
    marginBottom: 16,
  },
  instructionsList: {
    marginBottom: 8,
  },
  instructionItem: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  instructionNumber: {
    ...Typography.bodyBold,
    width: 24,
    height: 24,
    borderRadius: 12,
    textAlign: 'center',
    marginRight: 12,
  },
  instructionText: {
    ...Typography.body,
    flex: 1,
  },
  errorText: {
    ...Typography.body,
    color: '#E53E3E',
    marginBottom: 16,
  },
  startButton: {
    width: '100%',
  },
});