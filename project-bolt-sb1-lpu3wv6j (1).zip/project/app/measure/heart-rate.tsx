import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { Stack, useRouter } from 'expo-router';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import MeasurementInProgress from '@/components/MeasurementInProgress';
import { Heart } from 'lucide-react-native';
import { simulateHeartRateMeasurement } from '@/utils/measurements';
import { addHealthLogEntry } from '@/utils/storage';
import { getMeasurementInstructions } from '@/utils/measurements';

export default function HeartRateScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const [isMeasuring, setIsMeasuring] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  
  const totalMeasurementTime = 3000; // 3 seconds in ms
  const measurementInstructions = getMeasurementInstructions('heartRate');
  
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isMeasuring) {
      timer = setInterval(() => {
        setElapsedTime(prev => {
          // Cap at total measurement time
          const newTime = Math.min(prev + 100, totalMeasurementTime);
          return newTime;
        });
      }, 100);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isMeasuring]);
  
  useEffect(() => {
    if (elapsedTime >= totalMeasurementTime && isMeasuring) {
      completeHeartRateMeasurement();
    }
  }, [elapsedTime, isMeasuring]);
  
  const startMeasurement = () => {
    setIsMeasuring(true);
    setElapsedTime(0);
    setResult(null);
    setError(null);
    setSaved(false);
  };
  
  const completeHeartRateMeasurement = async () => {
    try {
      const heartRate = await simulateHeartRateMeasurement();
      setResult(heartRate);
      setIsMeasuring(false);
    } catch (error) {
      console.error('Error measuring heart rate:', error);
      setError('Failed to measure heart rate. Please try again.');
      setIsMeasuring(false);
    }
  };
  
  const cancelMeasurement = () => {
    setIsMeasuring(false);
    setElapsedTime(0);
  };
  
  const saveToHealthLog = async () => {
    if (result) {
      try {
        await addHealthLogEntry({
          timestamp: new Date().toISOString(),
          type: 'Heart Rate (PPG)',
          value: result,
          details: 'Measured using camera (simulated)'
        });
        setSaved(true);
      } catch (error) {
        console.error('Error saving heart rate:', error);
        setError('Failed to save to health log. Please try again.');
      }
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen 
        options={{ 
          headerShown: true, 
          title: 'Heart Rate',
          headerTintColor: colors.text,
          headerStyle: {
            backgroundColor: colors.background,
          },
        }} 
      />
      
      <View style={styles.content}>
        {isMeasuring ? (
          <View style={styles.measuringContainer}>
            <MeasurementInProgress
              type="heartRate"
              elapsedTime={elapsedTime}
              totalTime={totalMeasurementTime}
              instructions={measurementInstructions}
            />
            <Button
              title="Cancel"
              onPress={cancelMeasurement}
              variant="ghost"
              style={styles.cancelButton}
            />
          </View>
        ) : result ? (
          <View style={styles.resultContainer}>
            <Text style={[styles.resultTitle, { color: colors.text }]}>
              Measurement Complete
            </Text>
            
            <Card style={styles.resultCard}>
              <View style={styles.resultValue}>
                <Heart size={24} color={colors.heartRate} style={styles.resultIcon} />
                <Text style={[styles.heartRateValue, { color: colors.text }]}>
                  {result}
                  <Text style={[styles.heartRateUnit, { color: colors.tabIconDefault }]}> BPM</Text>
                </Text>
              </View>
              
              <Text style={[styles.resultStatus, { color: getHeartRateStatusColor(result, colors) }]}>
                {getHeartRateStatus(result)}
              </Text>
              
              <Text style={[styles.resultDescription, { color: colors.tabIconDefault }]}>
                {getHeartRateDescription(result)}
              </Text>
            </Card>
            
            {!saved ? (
              <Button
                title="Save to Health Log"
                onPress={saveToHealthLog}
                style={styles.saveButton}
              />
            ) : (
              <Text style={[styles.savedText, { color: colors.activity }]}>
                Saved to Health Log ✓
              </Text>
            )}
            
            <Button
              title="Measure Again"
              onPress={startMeasurement}
              variant="outline"
              style={styles.measureAgainButton}
            />
          </View>
        ) : (
          <View style={styles.startContainer}>
            <Card style={styles.instructionsCard}>
              <Text style={[styles.instructionsTitle, { color: colors.text }]}>
                Heart Rate Measurement
              </Text>
              
              <Text style={[styles.instructionsText, { color: colors.tabIconDefault }]}>
                This feature simulates measuring your heart rate using your device's camera
                and flash (photoplethysmography or PPG).
              </Text>
              
              <View style={styles.instructionsList}>
                {measurementInstructions.map((instruction, index) => (
                  <View key={index} style={styles.instructionItem}>
                    <Text style={[styles.instructionNumber, { color: colors.tint }]}>
                      {index + 1}
                    </Text>
                    <Text style={[styles.instructionText, { color: colors.text }]}>
                      {instruction}
                    </Text>
                  </View>
                ))}
              </View>
            </Card>
            
            {error && (
              <Text style={styles.errorText}>{error}</Text>
            )}
            
            <Button
              title="Start Measurement"
              onPress={startMeasurement}
              style={styles.startButton}
            />
          </View>
        )}
      </View>
    </View>
  );
}

// Helper functions for heart rate status and descriptions
function getHeartRateStatus(heartRate: number): string {
  if (heartRate < 60) return 'Below Normal';
  if (heartRate <= 100) return 'Normal';
  return 'Above Normal';
}

function getHeartRateStatusColor(heartRate: number, colors: any): string {
  if (heartRate < 60) return colors.heartSound; // Blue for low
  if (heartRate <= 100) return colors.activity; // Green for normal
  return colors.notification; // Red for high
}

function getHeartRateDescription(heartRate: number): string {
  if (heartRate < 60) {
    return 'Your simulated heart rate is below the typical resting range. Low heart rate may be normal for athletes or those on certain medications.';
  }
  if (heartRate <= 100) {
    return 'Your simulated heart rate is within the normal resting range for adults (60-100 BPM).';
  }
  return 'Your simulated heart rate is above the typical resting range. This may be due to activity, stress, caffeine, or other factors.';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  measuringContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelButton: {
    marginTop: 24,
  },
  resultContainer: {
    flex: 1,
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 20 : 0,
  },
  resultTitle: {
    ...Typography.heading2,
    marginBottom: 24,
  },
  resultCard: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 24,
  },
  resultValue: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultIcon: {
    marginRight: 12,
  },
  heartRateValue: {
    ...Typography.heading1,
    fontSize: 48,
  },
  heartRateUnit: {
    ...Typography.heading3,
  },
  resultStatus: {
    ...Typography.heading3,
    marginBottom: 8,
  },
  resultDescription: {
    ...Typography.body,
    textAlign: 'center',
  },
  saveButton: {
    marginBottom: 12,
    width: '100%',
  },
  savedText: {
    ...Typography.bodyBold,
    marginBottom: 12,
  },
  measureAgainButton: {
    width: '100%',
  },
  startContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  instructionsCard: {
    width: '100%',
    marginBottom: 24,
  },
  instructionsTitle: {
    ...Typography.heading3,
    marginBottom: 16,
  },
  instructionsText: {
    ...Typography.body,
    marginBottom: 16,
  },
  instructionsList: {
    marginBottom: 8,
  },
  instructionItem: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  instructionNumber: {
    ...Typography.bodyBold,
    width: 24,
    height: 24,
    borderRadius: 12,
    textAlign: 'center',
    marginRight: 12,
  },
  instructionText: {
    ...Typography.body,
    flex: 1,
  },
  errorText: {
    ...Typography.body,
    color: '#E53E3E',
    marginBottom: 16,
  },
  startButton: {
    width: '100%',
  },
});