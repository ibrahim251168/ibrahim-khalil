import React, { useState, useEffect } from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { Stack, useRouter } from 'expo-router';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import MeasurementInProgress from '@/components/MeasurementInProgress';
import { Mic } from 'lucide-react-native';
import { simulateHeartSoundRecording } from '@/utils/measurements';
import { addHealthLogEntry } from '@/utils/storage';
import { getMeasurementInstructions } from '@/utils/measurements';

export default function HeartSoundScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const [isRecording, setIsRecording] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  
  const totalRecordingTime = 4000; // 4 seconds in ms
  const recordingInstructions = getMeasurementInstructions('heartSound');
  
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isRecording) {
      timer = setInterval(() => {
        setElapsedTime(prev => {
          // Cap at total recording time
          const newTime = Math.min(prev + 100, totalRecordingTime);
          return newTime;
        });
      }, 100);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isRecording]);
  
  useEffect(() => {
    if (elapsedTime >= totalRecordingTime && isRecording) {
      completeHeartSoundRecording();
    }
  }, [elapsedTime, isRecording]);
  
  const startRecording = () => {
    setIsRecording(true);
    setElapsedTime(0);
    setResult(null);
    setError(null);
    setSaved(false);
  };
  
  const completeHeartSoundRecording = async () => {
    try {
      const recordingResult = await simulateHeartSoundRecording();
      setResult(recordingResult);
      setIsRecording(false);
    } catch (error) {
      console.error('Error recording heart sound:', error);
      setError('Failed to record heart sound. Please try again.');
      setIsRecording(false);
    }
  };
  
  const cancelRecording = () => {
    setIsRecording(false);
    setElapsedTime(0);
  };
  
  const saveToHealthLog = async () => {
    if (result) {
      try {
        await addHealthLogEntry({
          timestamp: new Date().toISOString(),
          type: 'Heart Sound Recording',
          value: 'Recording completed',
          details: 'Heart sound recording (simulated)'
        });
        setSaved(true);
      } catch (error) {
        console.error('Error saving heart sound recording:', error);
        setError('Failed to save to health log. Please try again.');
      }
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen 
        options={{ 
          headerShown: true, 
          title: 'Heart Sound',
          headerTintColor: colors.text,
          headerStyle: {
            backgroundColor: colors.background,
          },
        }} 
      />
      
      <View style={styles.content}>
        {isRecording ? (
          <View style={styles.recordingContainer}>
            <MeasurementInProgress
              type="heartSound"
              elapsedTime={elapsedTime}
              totalTime={totalRecordingTime}
              instructions={recordingInstructions}
            />
            <Button
              title="Cancel"
              onPress={cancelRecording}
              variant="ghost"
              style={styles.cancelButton}
            />
          </View>
        ) : result ? (
          <View style={styles.resultContainer}>
            <Text style={[styles.resultTitle, { color: colors.text }]}>
              Recording Complete
            </Text>
            
            <Card style={styles.resultCard}>
              <View style={styles.resultHeader}>
                <Mic size={24} color={colors.heartSound} style={styles.resultIcon} />
                <Text style={[styles.resultHeaderText, { color: colors.text }]}>
                  Heart Sound Recording
                </Text>
              </View>
              
              <Text style={[styles.resultStatus, { color: colors.activity }]}>
                Recording Successful
              </Text>
              
              <Text style={[styles.resultDescription, { color: colors.tabIconDefault }]}>
                This simulated recording would capture the sounds produced by your heart, including
                the "lub-dub" sounds of your heartbeat. In a real application, this recording could
                be analyzed to identify potential abnormalities.
              </Text>
            </Card>
            
            {!saved ? (
              <Button
                title="Save to Health Log"
                onPress={saveToHealthLog}
                style={styles.saveButton}
              />
            ) : (
              <Text style={[styles.savedText, { color: colors.activity }]}>
                Saved to Health Log ✓
              </Text>
            )}
            
            <Button
              title="Record Again"
              onPress={startRecording}
              variant="outline"
              style={styles.recordAgainButton}
            />
          </View>
        ) : (
          <View style={styles.startContainer}>
            <Card style={styles.instructionsCard}>
              <Text style={[styles.instructionsTitle, { color: colors.text }]}>
                Heart Sound Recording
              </Text>
              
              <Text style={[styles.instructionsText, { color: colors.tabIconDefault }]}>
                This feature simulates recording the sounds made by your heart using your
                device's microphone. These recordings could help identify potential irregularities
                in heart sounds.
              </Text>
              
              <View style={styles.instructionsList}>
                {recordingInstructions.map((instruction, index) => (
                  <View key={index} style={styles.instructionItem}>
                    <Text style={[styles.instructionNumber, { color: colors.heartSound }]}>
                      {index + 1}
                    </Text>
                    <Text style={[styles.instructionText, { color: colors.text }]}>
                      {instruction}
                    </Text>
                  </View>
                ))}
              </View>
            </Card>
            
            {error && (
              <Text style={styles.errorText}>{error}</Text>
            )}
            
            <Button
              title="Start Recording"
              onPress={startRecording}
              style={[styles.startButton, { backgroundColor: colors.heartSound }]}
            />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  recordingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelButton: {
    marginTop: 24,
  },
  resultContainer: {
    flex: 1,
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 20 : 0,
  },
  resultTitle: {
    ...Typography.heading2,
    marginBottom: 24,
  },
  resultCard: {
    width: '100%',
    marginBottom: 24,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultIcon: {
    marginRight: 12,
  },
  resultHeaderText: {
    ...Typography.heading3,
  },
  resultStatus: {
    ...Typography.bodyBold,
    marginBottom: 12,
  },
  resultDescription: {
    ...Typography.body,
  },
  saveButton: {
    marginBottom: 12,
    width: '100%',
    backgroundColor: '#3182CE',
  },
  savedText: {
    ...Typography.bodyBold,
    marginBottom: 12,
  },
  recordAgainButton: {
    width: '100%',
    borderColor: '#3182CE',
  },
  startContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  instructionsCard: {
    width: '100%',
    marginBottom: 24,
  },
  instructionsTitle: {
    ...Typography.heading3,
    marginBottom: 16,
  },
  instructionsText: {
    ...Typography.body,
    marginBottom: 16,
  },
  instructionsList: {
    marginBottom: 8,
  },
  instructionItem: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  instructionNumber: {
    ...Typography.bodyBold,
    width: 24,
    height: 24,
    borderRadius: 12,
    textAlign: 'center',
    marginRight: 12,
  },
  instructionText: {
    ...Typography.body,
    flex: 1,
  },
  errorText: {
    ...Typography.body,
    color: '#E53E3E',
    marginBottom: 16,
  },
  startButton: {
    width: '100%',
  },
});