import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, RefreshControl, Alert } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { HealthLogEntry } from '@/types/health';
import { getHealthLog, deleteHealthLogEntry } from '@/utils/storage';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { useRouter } from 'expo-router';
import { Plus, CircleAlert as AlertCircle } from 'lucide-react-native';
import LogEntryItem from '@/components/LogEntryItem';

export default function LogScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const [entries, setEntries] = useState<HealthLogEntry[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  
  const loadEntries = async () => {
    const logEntries = await getHealthLog();
    setEntries(logEntries);
  };
  
  useEffect(() => {
    loadEntries();
  }, []);
  
  const handleRefresh = async () => {
    setRefreshing(true);
    await loadEntries();
    setRefreshing(false);
  };
  
  const handleDelete = async (id: string) => {
    try {
      await deleteHealthLogEntry(id);
      setEntries(entries.filter(entry => entry.id !== id));
    } catch (error) {
      console.error('Error deleting entry:', error);
      Alert.alert('Error', 'Failed to delete entry. Please try again.');
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <Text style={[styles.title, { color: colors.text }]}>
            Health Log
          </Text>
          <Text style={[styles.subtitle, { color: colors.tabIconDefault }]}>
            View and manage your health data
          </Text>
        </View>
        <Button
          title="Add"
          onPress={() => router.push('/log/add')}
          style={styles.addButton}
          size="small"
        />
      </View>
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
      >
        {entries.length > 0 ? (
          <Card padding="medium" style={styles.entriesCard}>
            {entries.map(entry => (
              <LogEntryItem 
                key={entry.id} 
                entry={entry} 
                onDelete={handleDelete}
              />
            ))}
          </Card>
        ) : (
          <View style={styles.emptyState}>
            <Card style={styles.emptyStateCard}>
              <AlertCircle size={40} color={colors.tabIconDefault} style={styles.emptyIcon} />
              <Text style={[styles.emptyTitle, { color: colors.text }]}>
                No entries yet
              </Text>
              <Text style={[styles.emptyDescription, { color: colors.tabIconDefault }]}>
                Start tracking your heart health by adding entries to your log.
              </Text>
              <Button
                title="Add New Entry"
                onPress={() => router.push('/log/add')}
                style={styles.emptyAddButton}
              />
            </Card>
          </View>
        )}
      </ScrollView>
      
      <View style={[styles.addButtonContainer, { backgroundColor: colors.background }]}>
        <Button
          title="Add New Entry"
          onPress={() => router.push('/log/add')}
          style={styles.floatingAddButton}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 60,
    paddingBottom: 16,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    ...Typography.heading1,
  },
  subtitle: {
    ...Typography.body,
  },
  addButton: {
    marginLeft: 8,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 80,
  },
  entriesCard: {
    marginBottom: 16,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: 300,
  },
  emptyStateCard: {
    alignItems: 'center',
    padding: 32,
  },
  emptyIcon: {
    marginBottom: 16,
  },
  emptyTitle: {
    ...Typography.heading3,
    marginBottom: 8,
  },
  emptyDescription: {
    ...Typography.body,
    textAlign: 'center',
    marginBottom: 24,
  },
  emptyAddButton: {
    minWidth: 160,
  },
  addButtonContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    borderTopWidth: 1,
  },
  floatingAddButton: {
    width: '100%',
  },
});