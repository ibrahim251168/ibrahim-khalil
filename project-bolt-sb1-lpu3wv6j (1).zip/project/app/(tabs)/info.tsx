import React from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import Card from '@/components/ui/Card';
import { Heart, CircleAlert as AlertCircle, Activity, Pill, HeartPulse, Info } from 'lucide-react-native';

export default function InfoScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const openLink = (url: string) => {
    Linking.canOpenURL(url).then(supported => {
      if (supported) {
        Linking.openURL(url);
      } else {
        console.log("Don't know how to open URI: " + url);
      }
    });
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>
          Heart Health Information
        </Text>
        <Text style={[styles.subtitle, { color: colors.tabIconDefault }]}>
          Educational resources and tips
        </Text>
      </View>
      
      <ScrollView style={styles.scrollView}>
        <Card style={styles.card}>
          <View style={styles.cardHeader}>
            <Heart size={24} color={colors.heartRate} />
            <Text style={[styles.cardTitle, { color: colors.text }]}>
              About Heart Health
            </Text>
          </View>
          
          <Text style={[styles.cardText, { color: colors.text }]}>
            Heart health is vital for overall well-being. Regular monitoring can help
            identify potential issues early. This app provides tools to track your heart metrics
            and maintain a health log.
          </Text>
          
          <Text style={[styles.cardText, { color: colors.text }]}>
            Remember that this app is for educational and personal tracking purposes only and is
            not a replacement for professional medical advice.
          </Text>
        </Card>
        
        <Card style={styles.card}>
          <View style={styles.cardHeader}>
            <AlertCircle size={24} color={colors.notification} />
            <Text style={[styles.cardTitle, { color: colors.text }]}>
              Warning Signs
            </Text>
          </View>
          
          <Text style={[styles.cardText, { color: colors.text, fontWeight: 'bold' }]}>
            Seek medical attention immediately if you experience:
          </Text>
          
          <View style={styles.bulletPoints}>
            <Text style={[styles.bulletPoint, { color: colors.text }]}>
              • Chest pain or discomfort
            </Text>
            <Text style={[styles.bulletPoint, { color: colors.text }]}>
              • Shortness of breath
            </Text>
            <Text style={[styles.bulletPoint, { color: colors.text }]}>
              • Pain or discomfort in the arms, back, neck, jaw, or stomach
            </Text>
            <Text style={[styles.bulletPoint, { color: colors.text }]}>
              • Breaking out in a cold sweat, nausea, or lightheadedness
            </Text>
          </View>
        </Card>
        
        <Card style={styles.card}>
          <View style={styles.cardHeader}>
            <Activity size={24} color={colors.activity} />
            <Text style={[styles.cardTitle, { color: colors.text }]}>
              Healthy Lifestyle Tips
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipTitle, { color: colors.text }]}>Regular Exercise</Text>
            <Text style={[styles.tipDescription, { color: colors.tabIconDefault }]}>
              Aim for at least 150 minutes of moderate aerobic activity or 75 minutes of vigorous 
              aerobic activity weekly.
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipTitle, { color: colors.text }]}>Balanced Diet</Text>
            <Text style={[styles.tipDescription, { color: colors.tabIconDefault }]}>
              Eat a diet rich in fruits, vegetables, whole grains, lean proteins, and healthy fats.
              Limit salt, sugar, and processed foods.
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipTitle, { color: colors.text }]}>Stress Management</Text>
            <Text style={[styles.tipDescription, { color: colors.tabIconDefault }]}>
              Practice stress-reduction techniques like meditation, deep breathing, or yoga.
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipTitle, { color: colors.text }]}>Regular Checkups</Text>
            <Text style={[styles.tipDescription, { color: colors.tabIconDefault }]}>
              Schedule regular appointments with your healthcare provider to monitor your heart health.
            </Text>
          </View>
        </Card>
        
        <Card style={styles.card}>
          <View style={styles.cardHeader}>
            <HeartPulse size={24} color={colors.bloodPressure} />
            <Text style={[styles.cardTitle, { color: colors.text }]}>
              Understanding Measurements
            </Text>
          </View>
          
          <View style={styles.infoItem}>
            <Text style={[styles.infoTitle, { color: colors.text }]}>Heart Rate</Text>
            <Text style={[styles.infoDescription, { color: colors.tabIconDefault }]}>
              Normal resting heart rate for adults: 60-100 beats per minute.
              Athletes may have lower resting heart rates, typically 40-60 BPM.
            </Text>
          </View>
          
          <View style={styles.infoItem}>
            <Text style={[styles.infoTitle, { color: colors.text }]}>Blood Pressure</Text>
            <Text style={[styles.infoDescription, { color: colors.tabIconDefault }]}>
              Normal: Less than 120/80 mmHg
              Elevated: 120-129/less than 80 mmHg
              High: 130/80 mmHg or higher
            </Text>
          </View>
        </Card>
        
        <Card style={styles.card}>
          <View style={styles.cardHeader}>
            <Info size={24} color={colors.symptom} />
            <Text style={[styles.cardTitle, { color: colors.text }]}>
              Additional Resources
            </Text>
          </View>
          
          <TouchableOpacity 
            style={styles.resourceItem}
            onPress={() => openLink('https://www.heart.org/')}
          >
            <Text style={[styles.resourceTitle, { color: colors.tint }]}>
              American Heart Association
            </Text>
            <Text style={[styles.resourceDescription, { color: colors.tabIconDefault }]}>
              Comprehensive information on heart health and disease prevention.
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.resourceItem}
            onPress={() => openLink('https://www.nhlbi.nih.gov/')}
          >
            <Text style={[styles.resourceTitle, { color: colors.tint }]}>
              National Heart, Lung, and Blood Institute
            </Text>
            <Text style={[styles.resourceDescription, { color: colors.tabIconDefault }]}>
              Research and educational resources on heart health.
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.resourceItem}
            onPress={() => openLink('https://www.who.int/health-topics/cardiovascular-diseases')}
          >
            <Text style={[styles.resourceTitle, { color: colors.tint }]}>
              World Health Organization
            </Text>
            <Text style={[styles.resourceDescription, { color: colors.tabIconDefault }]}>
              Global perspective on cardiovascular diseases and prevention.
            </Text>
          </TouchableOpacity>
        </Card>
        
        <Text style={[styles.disclaimer, { color: colors.tabIconDefault }]}>
          This app is for educational purposes only and not intended as a medical device or diagnostic tool.
          Always consult healthcare professionals for medical advice.
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 16,
    paddingTop: 60,
    paddingBottom: 16,
  },
  title: {
    ...Typography.heading1,
  },
  subtitle: {
    ...Typography.body,
  },
  scrollView: {
    flex: 1,
  },
  card: {
    marginHorizontal: 16,
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    ...Typography.heading3,
    marginLeft: 12,
  },
  cardText: {
    ...Typography.body,
    marginBottom: 12,
  },
  bulletPoints: {
    marginTop: 8,
  },
  bulletPoint: {
    ...Typography.body,
    marginBottom: 8,
  },
  tipItem: {
    marginBottom: 16,
  },
  tipTitle: {
    ...Typography.bodyBold,
    marginBottom: 4,
  },
  tipDescription: {
    ...Typography.body,
  },
  infoItem: {
    marginBottom: 16,
  },
  infoTitle: {
    ...Typography.bodyBold,
    marginBottom: 4,
  },
  infoDescription: {
    ...Typography.body,
  },
  resourceItem: {
    marginBottom: 16,
  },
  resourceTitle: {
    ...Typography.bodyBold,
    marginBottom: 4,
    textDecorationLine: 'underline',
  },
  resourceDescription: {
    ...Typography.body,
  },
  disclaimer: {
    ...Typography.caption,
    textAlign: 'center',
    marginHorizontal: 16,
    marginBottom: 32,
    fontStyle: 'italic',
  },
});