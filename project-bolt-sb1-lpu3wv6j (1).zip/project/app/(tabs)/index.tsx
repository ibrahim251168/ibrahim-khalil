import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, RefreshControl, Platform } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { HealthLogEntry } from '@/types/health';
import { getRecentEntries } from '@/utils/storage';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import { useRouter } from 'expo-router';
import { Heart, Activity, CirclePlus as PlusCircle, CircleAlert as AlertCircle, ChartPie as PieChart } from 'lucide-react-native';
import HealthMetricCard from '@/components/HealthMetricCard';
import LogEntryItem from '@/components/LogEntryItem';
import { formatDistanceToNow } from '@/utils/dateFormat';

export default function HomeScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const [recentEntries, setRecentEntries] = useState<HealthLogEntry[]>([]);
  const [lastHeartRate, setLastHeartRate] = useState<HealthLogEntry | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  
  const loadData = async () => {
    const entries = await getRecentEntries(7);
    setRecentEntries(entries);
    
    // Find most recent heart rate entry
    const heartRateEntry = entries.find(entry => 
      entry.type.toLowerCase().includes('heart rate') || 
      entry.type.toLowerCase().includes('heartrate')
    );
    setLastHeartRate(heartRateEntry || null);
  };
  
  useEffect(() => {
    loadData();
  }, []);
  
  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };
  
  const getGreeting = () => {
    const hours = new Date().getHours();
    
    if (hours < 12) {
      return 'Good Morning';
    } else if (hours < 18) {
      return 'Good Afternoon';
    } else {
      return 'Good Evening';
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={styles.header}>
          <Text style={[styles.greeting, { color: colors.text }]}>
            {getGreeting()}
          </Text>
          <Text style={[styles.subtitle, { color: colors.tabIconDefault }]}>
            Keep track of your heart health
          </Text>
        </View>
        
        <View style={styles.quickActions}>
          <Button 
            title="Measure Heart Rate" 
            onPress={() => router.push('/measure/heart-rate')}
            variant="primary"
            style={styles.actionButton}
          />
          <Button 
            title="Add Health Log" 
            onPress={() => router.push('/log/add')}
            variant="outline"
            style={styles.actionButton}
          />
        </View>
        
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          Health Metrics
        </Text>
        
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.metricsScrollContainer}
        >
          <HealthMetricCard
            title="Heart Rate"
            value={lastHeartRate ? lastHeartRate.value : '--'}
            unit="BPM"
            icon={<Heart size={20} color={colors.heartRate} />}
            color={colors.heartRate}
            lastUpdated={lastHeartRate ? formatDistanceToNow(new Date(lastHeartRate.timestamp)) : 'Not available'}
          />
          
          <HealthMetricCard
            title="Activity"
            value="Monitor"
            icon={<Activity size={20} color={colors.activity} />}
            color={colors.activity}
            lastUpdated="Tap to record"
          />
          
          <HealthMetricCard
            title="Health Log"
            value={recentEntries.length}
            unit="entries"
            icon={<PieChart size={20} color={colors.symptom} />}
            color={colors.symptom}
            lastUpdated="Past 7 days"
          />
        </ScrollView>
        
        <View style={styles.recentEntriesContainer}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>
              Recent Entries
            </Text>
            <Button
              title="View All"
              onPress={() => router.push('/log')}
              variant="ghost"
              size="small"
            />
          </View>
          
          <Card padding="medium" style={{ marginBottom: 16 }}>
            {recentEntries.length > 0 ? (
              <View>
                {recentEntries.slice(0, 3).map((entry) => (
                  <LogEntryItem key={entry.id} entry={entry} />
                ))}
                
                {recentEntries.length > 3 && (
                  <Button
                    title="View More"
                    onPress={() => router.push('/log')}
                    variant="ghost"
                    size="small"
                    style={styles.viewMoreButton}
                  />
                )}
              </View>
            ) : (
              <View style={styles.emptyContainer}>
                <AlertCircle size={24} color={colors.tabIconDefault} style={styles.emptyIcon} />
                <Text style={[styles.emptyText, { color: colors.tabIconDefault }]}>
                  No recent entries found
                </Text>
                <Button
                  title="Add Entry"
                  onPress={() => router.push('/log/add')}
                  size="small"
                  style={styles.addEntryButton}
                />
              </View>
            )}
          </Card>
        </View>
        
        <Card style={styles.disclaimerCard} elevation="low">
          <Text style={[styles.disclaimerText, { color: colors.tabIconDefault }]}>
            This app is for personal monitoring only and is not a replacement for professional medical advice.
          </Text>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    marginTop: Platform.OS === 'ios' ? 40 : 20,
    marginBottom: 24,
  },
  greeting: {
    ...Typography.heading1,
    marginBottom: 8,
  },
  subtitle: {
    ...Typography.body,
  },
  quickActions: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  actionButton: {
    flex: 1,
    marginRight: 8,
  },
  sectionTitle: {
    ...Typography.heading3,
    marginBottom: 16,
  },
  metricsScrollContainer: {
    paddingRight: 16,
  },
  recentEntriesContainer: {
    marginTop: 24,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 16,
  },
  emptyIcon: {
    marginBottom: 8,
  },
  emptyText: {
    ...Typography.body,
    textAlign: 'center',
    marginBottom: 16,
  },
  addEntryButton: {
    minWidth: 120,
  },
  viewMoreButton: {
    alignSelf: 'center',
    marginTop: 8,
  },
  disclaimerCard: {
    backgroundColor: 'transparent',
    borderStyle: 'dashed',
  },
  disclaimerText: {
    ...Typography.caption,
    textAlign: 'center',
  },
});