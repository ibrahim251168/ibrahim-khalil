import React from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { useRouter } from 'expo-router';
import MeasurementCard from '@/components/MeasurementCard';
import Card from '@/components/ui/Card';
import { TriangleAlert as AlertTriangle } from 'lucide-react-native';

export default function MeasureScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const navigateToMeasurement = (type: string) => {
    router.push(`/measure/${type}`);
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>
          Measurements
        </Text>
        <Text style={[styles.description, { color: colors.tabIconDefault }]}>
          Take health measurements using your device's sensors
        </Text>
      </View>
      
      <ScrollView style={styles.scrollView}>
        <View style={styles.measurementsList}>
          <MeasurementCard 
            type="heartRate" 
            onPress={() => navigateToMeasurement('heart-rate')} 
          />
          
          <MeasurementCard 
            type="heartSound" 
            onPress={() => navigateToMeasurement('heart-sound')} 
          />
          
          <MeasurementCard 
            type="chestVibration" 
            onPress={() => navigateToMeasurement('chest-vibration')} 
          />
        </View>
        
        <Card style={styles.disclaimerCard} elevation="low">
          <View style={styles.disclaimerContent}>
            <AlertTriangle size={20} color={colors.notification} style={styles.disclaimerIcon} />
            <Text style={[styles.disclaimerText, { color: colors.text }]}>
              Measurements are simulated for educational purposes only and do not represent actual medical diagnostics.
            </Text>
          </View>
        </Card>
        
        <Card style={styles.tipsCard}>
          <Text style={[styles.tipsTitle, { color: colors.text }]}>
            Tips for Accurate Measurements
          </Text>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipNumber, { color: colors.tint }]}>1</Text>
            <Text style={[styles.tipText, { color: colors.text }]}>
              Find a quiet, well-lit environment before taking measurements
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipNumber, { color: colors.tint }]}>2</Text>
            <Text style={[styles.tipText, { color: colors.text }]}>
              Sit comfortably and remain still during measurements
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipNumber, { color: colors.tint }]}>3</Text>
            <Text style={[styles.tipText, { color: colors.text }]}>
              Follow on-screen instructions carefully for each measurement type
            </Text>
          </View>
          
          <View style={styles.tipItem}>
            <Text style={[styles.tipNumber, { color: colors.tint }]}>4</Text>
            <Text style={[styles.tipText, { color: colors.text }]}>
              Take measurements at similar times of day for consistency
            </Text>
          </View>
        </Card>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 16,
    paddingTop: 60,
    paddingBottom: 16,
  },
  title: {
    ...Typography.heading1,
    marginBottom: 8,
  },
  description: {
    ...Typography.body,
  },
  scrollView: {
    flex: 1,
  },
  measurementsList: {
    padding: 16,
  },
  disclaimerCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    borderStyle: 'dashed',
  },
  disclaimerContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  disclaimerIcon: {
    marginRight: 12,
    marginTop: 2,
  },
  disclaimerText: {
    ...Typography.caption,
    flex: 1,
  },
  tipsCard: {
    margin: 16,
    marginTop: 8,
  },
  tipsTitle: {
    ...Typography.heading4,
    marginBottom: 16,
  },
  tipItem: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-start',
  },
  tipNumber: {
    ...Typography.heading3,
    width: 24,
    marginRight: 12,
  },
  tipText: {
    ...Typography.body,
    flex: 1,
  },
});