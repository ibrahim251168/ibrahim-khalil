import React, { useState } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import ManualEntryForm from '@/components/ManualEntryForm';
import { ManualEntryData } from '@/types/health';
import { addHealthLogEntry } from '@/utils/storage';

export default function AddLogEntryScreen() {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  const router = useRouter();
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const handleSubmit = async (data: ManualEntryData) => {
    setLoading(true);
    setError(null);
    
    try {
      await addHealthLogEntry({
        timestamp: new Date().toISOString(),
        type: getTypeLabel(data.type),
        value: data.value,
        details: data.details
      });
      
      setLoading(false);
      router.back();
    } catch (error) {
      console.error('Error adding entry:', error);
      setError('Failed to save entry. Please try again.');
      setLoading(false);
    }
  };
  
  const getTypeLabel = (type: ManualEntryData['type']): string => {
    switch (type) {
      case 'bloodPressure': return 'Blood Pressure';
      case 'symptom': return 'Symptom';
      case 'activity': return 'Physical Activity';
      case 'medication': return 'Medication';
      case 'weight': return 'Weight';
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen 
        options={{ 
          headerShown: true, 
          title: 'Add Health Log Entry',
          headerTintColor: colors.text,
          headerStyle: {
            backgroundColor: colors.background,
          },
        }} 
      />
      
      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}
      
      <ManualEntryForm
        onSubmit={handleSubmit}
        onCancel={() => router.back()}
        loading={loading}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  errorContainer: {
    padding: 16,
    backgroundColor: '#FED7D7',
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
  },
  errorText: {
    ...Typography.body,
    color: '#E53E3E',
  },
});