export interface HealthLogEntry {
  id: string;
  timestamp: string;
  type: string;
  value: string | number;
  details?: string;
}

export type MeasurementType = 'heartRate' | 'heartSound' | 'chestVibration';

export interface HeartRateReading {
  value: number;
  timestamp: string;
}

export interface ManualEntryData {
  type: 'bloodPressure' | 'symptom' | 'activity' | 'medication' | 'weight';
  value: string;
  details?: string;
}