const tintColorLight = '#E53E3E';
const tintColorDark = '#F56565';

export default {
  light: {
    text: '#1A202C',
    background: '#F7FAFC',
    tint: tintColorLight,
    tabIconDefault: '#A0AEC0',
    tabIconSelected: tintColorLight,
    card: '#FFFFFF',
    border: '#E2E8F0',
    notification: '#FF4D4F',
    heartRate: '#E53E3E',
    heartSound: '#3182CE',
    chestVibration: '#38B2AC',
    symptom: '#DD6B20',
    medication: '#6B46C1',
    activity: '#2F855A',
    weight: '#718096',
    bloodPressure: '#D53F8C'
  },
  dark: {
    text: '#F7FAFC',
    background: '#1A202C',
    tint: tintColorDark,
    tabIconDefault: '#718096',
    tabIconSelected: tintColorDark,
    card: '#2D3748',
    border: '#4A5568',
    notification: '#FF4D4F',
    heartRate: '#F56565',
    heartSound: '#63B3ED',
    chestVibration: '#4FD1C5',
    symptom: '#F6AD55',
    medication: '#9F7AEA',
    activity: '#68D391',
    weight: '#A0AEC0',
    bloodPressure: '#ED64A6'
  },
};