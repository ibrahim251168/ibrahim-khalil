export const FontNames = {
  inter: {
    regular: 'Inter-Regular',
    medium: 'Inter-Medium',
    semiBold: 'Inter-SemiBold',
    bold: 'Inter-Bold',
  },
  outfit: {
    regular: 'Outfit-Regular',
    medium: 'Outfit-Medium',
    semiBold: 'Outfit-SemiBold',
    bold: 'Outfit-Bold',
  }
};

export const Typography = {
  heading1: {
    fontFamily: FontNames.outfit.bold,
    fontSize: 28,
    lineHeight: 34,
  },
  heading2: {
    fontFamily: FontNames.outfit.semiBold,
    fontSize: 24,
    lineHeight: 30,
  },
  heading3: {
    fontFamily: FontNames.outfit.semiBold,
    fontSize: 20,
    lineHeight: 26,
  },
  heading4: {
    fontFamily: FontNames.outfit.medium,
    fontSize: 18,
    lineHeight: 24,
  },
  body: {
    fontFamily: FontNames.inter.regular,
    fontSize: 16,
    lineHeight: 24,
  },
  bodyBold: {
    fontFamily: FontNames.inter.semiBold,
    fontSize: 16,
    lineHeight: 24,
  },
  caption: {
    fontFamily: FontNames.inter.regular,
    fontSize: 14,
    lineHeight: 20,
  },
  captionBold: {
    fontFamily: FontNames.inter.medium,
    fontSize: 14,
    lineHeight: 20,
  },
  small: {
    fontFamily: FontNames.inter.regular,
    fontSize: 12,
    lineHeight: 16,
  },
};