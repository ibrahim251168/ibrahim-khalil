import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { MeasurementType } from '@/types/health';
import { Heart, Mic, Activity } from 'lucide-react-native';

interface MeasurementInProgressProps {
  type: MeasurementType;
  elapsedTime: number;
  totalTime: number;
  instructions?: string[];
}

export default function MeasurementInProgress({ 
  type, 
  elapsedTime,
  totalTime,
  instructions = [] 
}: MeasurementInProgressProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;
  
  // Start pulsing animation
  useEffect(() => {
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 800,
          easing: Easing.out(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 800,
          easing: Easing.in(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );
    
    pulse.start();
    
    return () => {
      pulse.stop();
    };
  }, [pulseAnim]);
  
  // Update progress animation
  useEffect(() => {
    Animated.timing(progressAnim, {
      toValue: elapsedTime / totalTime,
      duration: 300,
      useNativeDriver: false,
    }).start();
  }, [elapsedTime, totalTime, progressAnim]);
  
  const getTypeDetails = () => {
    switch (type) {
      case 'heartRate':
        return {
          title: 'Measuring Heart Rate',
          icon: <Heart size={48} color={colors.heartRate} />,
          color: colors.heartRate
        };
      case 'heartSound':
        return {
          title: 'Recording Heart Sound',
          icon: <Mic size={48} color={colors.heartSound} />,
          color: colors.heartSound
        };
      case 'chestVibration':
        return {
          title: 'Recording Chest Vibration',
          icon: <Activity size={48} color={colors.chestVibration} />,
          color: colors.chestVibration
        };
    }
  };
  
  const { title, icon, color } = getTypeDetails();
  const progress = Math.min(Math.max(elapsedTime / totalTime, 0), 1);
  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });
  
  return (
    <View style={styles.container}>
      <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
      
      <View style={styles.iconContainer}>
        <Animated.View 
          style={[
            styles.pulseCircle,
            { 
              backgroundColor: color + '20',
              transform: [{ scale: pulseAnim }] 
            }
          ]} 
        />
        <View style={styles.iconInner}>{icon}</View>
      </View>
      
      <View style={styles.progressContainer}>
        <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
          <Animated.View 
            style={[
              styles.progressFill,
              { 
                backgroundColor: color,
                width: progressWidth
              }
            ]} 
          />
        </View>
        <Text style={[styles.progressText, { color: colors.tabIconDefault }]}>
          {Math.floor(progress * 100)}%
        </Text>
      </View>
      
      {instructions && instructions.length > 0 && (
        <View style={styles.instructionsContainer}>
          <Text style={[styles.instructionsTitle, { color: colors.text }]}>
            Instructions:
          </Text>
          {instructions.map((instruction, index) => (
            <Text 
              key={index} 
              style={[styles.instructionText, { color: colors.tabIconDefault }]}
            >
              • {instruction}
            </Text>
          ))}
        </View>
      )}
      
      <Text style={[styles.keepStillText, { color: color }]}>
        Please remain still during measurement
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
  },
  title: {
    ...Typography.heading2,
    marginBottom: 40,
    textAlign: 'center',
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 40,
    height: 120,
    width: 120,
  },
  pulseCircle: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
  },
  iconInner: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressContainer: {
    width: '100%',
    marginBottom: 32,
  },
  progressBar: {
    height: 8,
    borderRadius: 4,
    width: '100%',
    marginBottom: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    ...Typography.caption,
    textAlign: 'right',
  },
  instructionsContainer: {
    alignSelf: 'stretch',
    marginBottom: 24,
  },
  instructionsTitle: {
    ...Typography.bodyBold,
    marginBottom: 8,
  },
  instructionText: {
    ...Typography.body,
    marginBottom: 4,
  },
  keepStillText: {
    ...Typography.bodyBold,
  },
});