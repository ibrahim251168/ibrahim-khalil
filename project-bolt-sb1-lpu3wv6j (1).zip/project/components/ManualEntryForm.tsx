import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, ScrollView } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import Button from '@/components/ui/Button';
import { ManualEntryData } from '@/types/health';

interface ManualEntryFormProps {
  onSubmit: (data: ManualEntryData) => void;
  onCancel: () => void;
  loading?: boolean;
}

export default function ManualEntryForm({ 
  onSubmit,
  onCancel,
  loading = false
}: ManualEntryFormProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const [entryType, setEntryType] = useState<ManualEntryData['type']>('bloodPressure');
  const [value, setValue] = useState('');
  const [details, setDetails] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const handleSubmit = () => {
    if (!value.trim()) {
      setError('Please enter a value');
      return;
    }
    
    setError(null);
    onSubmit({
      type: entryType,
      value: value.trim(),
      details: details.trim() || undefined
    });
  };
  
  const getTypeLabel = () => {
    switch (entryType) {
      case 'bloodPressure': return 'Blood Pressure';
      case 'symptom': return 'Symptom';
      case 'activity': return 'Physical Activity';
      case 'medication': return 'Medication';
      case 'weight': return 'Weight';
    }
  };
  
  const getValuePlaceholder = () => {
    switch (entryType) {
      case 'bloodPressure': return 'e.g., 120/80';
      case 'symptom': return 'e.g., Chest pain';
      case 'activity': return 'e.g., Walking 30 minutes';
      case 'medication': return 'e.g., Aspirin 100mg';
      case 'weight': return 'e.g., 75 kg';
    }
  };
  
  const getDetailsPlaceholder = () => {
    switch (entryType) {
      case 'bloodPressure': return 'e.g., Measured after waking up';
      case 'symptom': return 'e.g., Pain level, duration, etc.';
      case 'activity': return 'e.g., Walking pace, location, etc.';
      case 'medication': return 'e.g., Taken with food, dosage, etc.';
      case 'weight': return 'e.g., Time of day, circumstances, etc.';
    }
  };
  
  const TypeButton = ({ type, label }: { type: ManualEntryData['type'], label: string }) => (
    <Button
      title={label}
      onPress={() => setEntryType(type)}
      variant={entryType === type ? 'primary' : 'outline'}
      size="small"
      style={styles.typeButton}
    />
  );
  
  return (
    <ScrollView style={styles.container}>
      <Text style={[styles.heading, { color: colors.text }]}>Add Health Log Entry</Text>
      
      <Text style={[styles.sectionHeading, { color: colors.text }]}>Entry Type</Text>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.typeButtonsContainer}
      >
        <TypeButton type="bloodPressure" label="Blood Pressure" />
        <TypeButton type="symptom" label="Symptom" />
        <TypeButton type="activity" label="Activity" />
        <TypeButton type="medication" label="Medication" />
        <TypeButton type="weight" label="Weight" />
      </ScrollView>
      
      <Text style={[styles.sectionHeading, { color: colors.text }]}>
        {getTypeLabel()} Value
      </Text>
      <TextInput
        style={[
          styles.input, 
          { 
            color: colors.text,
            borderColor: colors.border,
            backgroundColor: colorScheme === 'dark' ? '#2D3748' : '#F7FAFC'
          }
        ]}
        placeholder={getValuePlaceholder()}
        placeholderTextColor={colors.tabIconDefault}
        value={value}
        onChangeText={setValue}
      />
      
      <Text style={[styles.sectionHeading, { color: colors.text }]}>Details (Optional)</Text>
      <TextInput
        style={[
          styles.input, 
          styles.multilineInput,
          { 
            color: colors.text,
            borderColor: colors.border,
            backgroundColor: colorScheme === 'dark' ? '#2D3748' : '#F7FAFC'
          }
        ]}
        placeholder={getDetailsPlaceholder()}
        placeholderTextColor={colors.tabIconDefault}
        value={details}
        onChangeText={setDetails}
        multiline
        numberOfLines={3}
        textAlignVertical="top"
      />
      
      {error && <Text style={styles.errorText}>{error}</Text>}
      
      <View style={styles.buttonsContainer}>
        <Button
          title="Cancel"
          onPress={onCancel}
          variant="ghost"
          style={styles.button}
        />
        <Button
          title="Save Entry"
          onPress={handleSubmit}
          loading={loading}
          style={styles.button}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  heading: {
    ...Typography.heading2,
    marginBottom: 20,
  },
  sectionHeading: {
    ...Typography.bodyBold,
    marginBottom: 8,
    marginTop: 16,
  },
  typeButtonsContainer: {
    flexDirection: 'row',
    paddingRight: 16,
  },
  typeButton: {
    marginRight: 8,
  },
  input: {
    ...Typography.body,
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
  },
  multilineInput: {
    minHeight: 80,
    paddingTop: 12,
  },
  errorText: {
    ...Typography.caption,
    color: '#E53E3E',
    marginTop: 8,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
    marginBottom: 32,
  },
  button: {
    flex: 1,
    marginHorizontal: 4,
  },
});