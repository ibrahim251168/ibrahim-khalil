import React, { ReactNode } from 'react';
import { View, StyleSheet, ViewStyle, Platform } from 'react-native';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';

interface CardProps {
  children: ReactNode;
  style?: ViewStyle;
  elevation?: 'none' | 'low' | 'medium' | 'high';
  padding?: 'none' | 'small' | 'medium' | 'large';
}

export default function Card({ 
  children, 
  style, 
  elevation = 'medium',
  padding = 'medium' 
}: CardProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const getElevationStyle = () => {
    switch(elevation) {
      case 'none':
        return {};
      case 'low':
        return Platform.select({
          ios: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.1,
            shadowRadius: 2,
          },
          android: {
            elevation: 1,
          },
          web: {
            boxShadow: '0px 1px 2px rgba(0, 0, 0, 0.1)',
          },
        });
      case 'high':
        return Platform.select({
          ios: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.15,
            shadowRadius: 8,
          },
          android: {
            elevation: 5,
          },
          web: {
            boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.15)',
          },
        });
      case 'medium':
      default:
        return Platform.select({
          ios: {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
          },
          android: {
            elevation: 3,
          },
          web: {
            boxShadow: '0px 2px 6px rgba(0, 0, 0, 0.1)',
          },
        });
    }
  };
  
  const getPaddingStyle = () => {
    switch(padding) {
      case 'none':
        return { padding: 0 };
      case 'small':
        return { padding: 12 };
      case 'large':
        return { padding: 24 };
      case 'medium':
      default:
        return { padding: 16 };
    }
  };
  
  return (
    <View style={[
      styles.card,
      { backgroundColor: colors.card, borderColor: colors.border },
      getElevationStyle(),
      getPaddingStyle(),
      style
    ]}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'transparent',
    overflow: 'hidden',
  },
});