import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator,
  GestureResponderEvent,
  ViewStyle,
  TextStyle,
  Platform
} from 'react-native';
import { Typography } from '@/constants/Fonts';
import Colors from '@/constants/Colors';
import { useColorScheme } from 'react-native';

interface ButtonProps {
  title: string;
  onPress: (event: GestureResponderEvent) => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  loading?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export default function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  style,
  textStyle,
}: ButtonProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const buttonStyles: ViewStyle[] = [
    styles.button,
    styles[size],
    // Apply variant styles
    variant === 'primary' && { backgroundColor: colors.tint },
    variant === 'secondary' && { backgroundColor: colors.tabIconDefault },
    variant === 'outline' && { 
      backgroundColor: 'transparent', 
      borderWidth: 1, 
      borderColor: colors.tint 
    },
    variant === 'ghost' && { 
      backgroundColor: 'transparent'
    },
    disabled && { opacity: 0.5 },
    style as ViewStyle,
  ];
  
  const textStyles: TextStyle[] = [
    styles.text,
    styles[`${size}Text`],
    variant === 'primary' && { color: '#FFFFFF' },
    variant === 'secondary' && { color: '#FFFFFF' },
    variant === 'outline' && { color: colors.tint },
    variant === 'ghost' && { color: colors.tint },
    textStyle as TextStyle,
  ];
  
  return (
    <TouchableOpacity
      style={buttonStyles}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variant === 'primary' || variant === 'secondary' ? 'white' : colors.tint} 
        />
      ) : (
        <Text style={textStyles}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 3,
      },
      web: {
        boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)',
      },
    }),
  },
  small: {
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  medium: {
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  large: {
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  text: {
    ...Typography.bodyBold,
    textAlign: 'center',
  },
  smallText: {
    ...Typography.caption,
    fontFamily: Typography.captionBold.fontFamily,
  },
  mediumText: {
    ...Typography.body,
    fontFamily: Typography.bodyBold.fontFamily,
  },
  largeText: {
    ...Typography.heading4,
  },
});