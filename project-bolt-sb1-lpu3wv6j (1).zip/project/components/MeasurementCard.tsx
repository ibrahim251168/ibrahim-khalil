import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MeasurementType } from '@/types/health';
import Card from '@/components/ui/Card';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { Heart, Mic, Activity } from 'lucide-react-native';

interface MeasurementCardProps {
  type: MeasurementType;
  onPress: () => void;
}

export default function MeasurementCard({ type, onPress }: MeasurementCardProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const getTypeDetails = () => {
    switch (type) {
      case 'heartRate':
        return {
          title: 'Heart Rate',
          description: 'Measure your heart rate using your camera',
          icon: <Heart size={24} color={colors.heartRate} />,
          color: colors.heartRate
        };
      case 'heartSound':
        return {
          title: 'Heart Sound',
          description: 'Record your heart sounds using your microphone',
          icon: <Mic size={24} color={colors.heartSound} />,
          color: colors.heartSound
        };
      case 'chestVibration':
        return {
          title: 'Chest Vibration',
          description: 'Record chest vibrations using the accelerometer',
          icon: <Activity size={24} color={colors.chestVibration} />,
          color: colors.chestVibration
        };
      default:
        return {
          title: 'Measurement',
          description: 'Take a health measurement',
          icon: <Heart size={24} color={colors.tint} />,
          color: colors.tint
        };
    }
  };
  
  const { title, description, icon, color } = getTypeDetails();
  
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
      <Card style={styles.card}>
        <View style={[styles.iconContainer, { backgroundColor: color + '20' }]}>
          {icon}
        </View>
        <View style={styles.content}>
          <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
          <Text style={[styles.description, { color: colors.tabIconDefault }]}>
            {description}
          </Text>
        </View>
      </Card>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  iconContainer: {
    padding: 12,
    borderRadius: 12,
    marginRight: 16,
  },
  content: {
    flex: 1,
  },
  title: {
    ...Typography.bodyBold,
    marginBottom: 4,
  },
  description: {
    ...Typography.caption,
  },
});