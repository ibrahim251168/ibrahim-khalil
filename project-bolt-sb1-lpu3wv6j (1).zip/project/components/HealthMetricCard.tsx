import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Card from '@/components/ui/Card';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { ReactNode } from 'react';

interface HealthMetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon: ReactNode;
  color?: string;
  lastUpdated?: string;
}

export default function HealthMetricCard({ 
  title, 
  value, 
  unit, 
  icon,
  color,
  lastUpdated
}: HealthMetricCardProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  const metricColor = color || colors.tint;
  
  return (
    <Card style={styles.card} elevation="low">
      <View style={styles.header}>
        <View style={[styles.iconContainer, { backgroundColor: metricColor + '20' }]}>
          {icon}
        </View>
        <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
      </View>
      
      <View style={styles.valueContainer}>
        <Text style={[styles.value, { color: colors.text }]}>
          {value}
          {unit && <Text style={[styles.unit, { color: colors.tabIconDefault }]}> {unit}</Text>}
        </Text>
      </View>
      
      {lastUpdated && (
        <Text style={[styles.lastUpdated, { color: colors.tabIconDefault }]}>
          Last updated: {lastUpdated}
        </Text>
      )}
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: 8,
    marginBottom: 16,
    minWidth: 160,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    padding: 8,
    borderRadius: 8,
    marginRight: 8,
  },
  title: {
    ...Typography.captionBold,
  },
  valueContainer: {
    marginBottom: 4,
  },
  value: {
    ...Typography.heading2,
  },
  unit: {
    ...Typography.caption,
  },
  lastUpdated: {
    ...Typography.small,
  },
});