import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { HealthLogEntry } from '@/types/health';
import { useColorScheme } from 'react-native';
import Colors from '@/constants/Colors';
import { Typography } from '@/constants/Fonts';
import { Trash2 } from 'lucide-react-native';
import { formatDistanceToNow } from '@/utils/dateFormat';

interface LogEntryItemProps {
  entry: HealthLogEntry;
  onDelete?: (id: string) => void;
}

export default function LogEntryItem({ entry, onDelete }: LogEntryItemProps) {
  const colorScheme = useColorScheme() ?? 'light';
  const colors = Colors[colorScheme];
  
  // Function to determine entry type color
  const getEntryTypeColor = () => {
    const type = entry.type.toLowerCase();
    
    if (type.includes('heart rate') || type.includes('heartrate')) {
      return colors.heartRate;
    } else if (type.includes('heart sound') || type.includes('heartsound')) {
      return colors.heartSound;
    } else if (type.includes('chest') || type.includes('vibration')) {
      return colors.chestVibration;
    } else if (type.includes('symptom')) {
      return colors.symptom;
    } else if (type.includes('medication') || type.includes('drug')) {
      return colors.medication;
    } else if (type.includes('activity') || type.includes('exercise')) {
      return colors.activity;
    } else if (type.includes('weight')) {
      return colors.weight;
    } else if (type.includes('blood pressure') || type.includes('bp')) {
      return colors.bloodPressure;
    }
    
    return colors.tabIconDefault;
  };

  const entryTypeColor = getEntryTypeColor();
  const timeAgo = formatDistanceToNow(new Date(entry.timestamp));
  
  return (
    <View style={[styles.container, { borderColor: colors.border }]}>
      <View style={[styles.typeIndicator, { backgroundColor: entryTypeColor }]} />
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={[styles.type, { color: colors.text }]}>{entry.type}</Text>
          <Text style={[styles.time, { color: colors.tabIconDefault }]}>{timeAgo}</Text>
        </View>
        
        <Text style={[styles.value, { color: colors.text }]}>
          {entry.value}
        </Text>
        
        {entry.details ? (
          <Text style={[styles.details, { color: colors.tabIconDefault }]}>
            {entry.details}
          </Text>
        ) : null}
      </View>
      
      {onDelete && (
        <TouchableOpacity 
          style={styles.deleteButton}
          onPress={() => onDelete(entry.id)}
          hitSlop={{ top: 10, right: 10, bottom: 10, left: 10 }}
        >
          <Trash2 size={18} color={colors.tabIconDefault} />
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    paddingVertical: 12,
    backgroundColor: 'transparent',
  },
  typeIndicator: {
    width: 4,
    borderRadius: 2,
    marginRight: 12,
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  type: {
    ...Typography.bodyBold,
  },
  time: {
    ...Typography.small,
  },
  value: {
    ...Typography.body,
    marginBottom: 4,
  },
  details: {
    ...Typography.caption,
  },
  deleteButton: {
    paddingHorizontal: 8,
    justifyContent: 'center',
  },
});